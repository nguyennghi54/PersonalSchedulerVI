﻿from nlp import *
# ==========================================
# TEST CASE
# ==========================================
class TestData:
    test_data = [
        "Nhắc t họp nhóm lúc 10 giờ sáng mai ở phòng 302, nhắc trc 15 phút",
        "Đặt lịch đi xem phim với Lan vào tối nay lúc 19h tại CGV Vincom",
        "Chiều thứ 2 tuần sau có buổi training nhân sự từ 14h đến 16h30 ở hội trường A",
        "Nhắc nhở nộp báo cáo thực tập, deadline là 9h sáng ngày 05/11, nhắc trước 30 phút",
        "Sáng ngày kia đi khám sức khỏe tổng quát ở bệnh viện Đại học Y",
        "Có hẹn phỏng vấn lúc 10:30 ngày 15/11 tại công ty FPT",
        "Đá bóng giao hữu ở sân cỏ nhân tạo lúc 17h30 chiều mai, báo trước 1 tiếng",
        "Tham dự sinh nhật bạn bè ở nhà hàng Biển Đông vào tối 20/11",
        "Lịch học toán từ 18:00 tới 20:00 tối nay",
        "Nhắc uống thuốc sau ăn trưa lúc 12h30 hnay",
        "Họp online qua Zoom với khách hàng Nhật lúc 8h sáng thứ Sáu, nhắc trước 10 phút",
        "Đi siêu thị BigC mua đồ lúc 9h sáng chủ nhật tuần này",
        "Tối nay 8 giờ đi cafe với hội bạn cũ ở Highlands",
        "Tham gia hội thảo từ 8h đến 17h ngày 05/12 tại Landmark 81",
        "Nhắc trả sách ở thư viện vào 3 giờ chiều mai",
        "Chuyến bay đi Đà Nẵng cất cánh lúc 06:45 ngày 25/11, nhắc trước 120 phút",
        "Bảo vệ đồ án tốt nghiệp tại phòng 101 khu nhà A lúc 7h30 ngày 20/01/2026",
        "Đi đón em gái ở bến xe Mỹ Đình lúc 5h chiều thứ 5 tuần sau",
        "8h tối nay chơi game",
        "Có cuộc họp khẩn cấp lúc 14:00 chiều nay tại phòng Giám đốc, báo trước 5 phút",
        "Sáng mai 9 giờ đi làm giấy tờ ở UBND phường",
        "Lịch trực nhật lớp từ 6h30 tới 7h tuần sau",
        "Nhắc gọi điện chúc mừng sinh nhật Bố lúc 20h ngày 10/11",
        "Đăng ký môn học kỳ mới trên web trường lúc 10h sáng ngày mốt",
        "Team building công ty tại Hạ Long từ 07:00 ngày 15/12 đến 17:00 ngày 16/12",
        "Làm bài tập lớn môn Web ở thư viện lúc 9h sáng nay",
        "Nhắc t đặt vé tàu về quê lúc 8h sáng ngày 01/12, báo sớm 15 phút",
        "Hẹn bác sĩ nha khoa lúc 17h30 thứ 7 ở phòng khám Tâm Đức",
        "Chúc Tết ở nhà thầy cô lúc 10h tuần sau",
        "Sửa máy tính ở tiệm PC Gear lúc 3h-7h chiều nay"
    ]

    # ==========================================
    # CHẠY TEST
    # ==========================================
    pipeline = SchedulerMain()

    print(f"{'ID':<3} | {'EVENT (Extracted)':<30} | {'TIME (Start - End)':<50} | {'LOCATION':<20} | {'REMIND'}")
    print("-" * 115)

    for i, text in enumerate(test_data):
        res = pipeline.process(text)

        event = res['event'][:50]
        # Rút gọn Location
        loc = str(res['location'])[:28] if res['location'] else "---"
        s_str = res['start_time']
        e_str = res['end_time']
        if e_str:
            # Tách ngày và giờ để so sánh
            s_date, s_hour = s_str.split(' ')
            e_date, e_hour = e_str.split(' ')

            time_display = f"{s_str} -> {e_str}"
        else:
            # Nếu không có End time
            time_display = s_str

        # Reminder
        remind = f"{res['reminder_minutes']}p" if res['reminder_minutes'] > 0 else "-"
        print(f"{i + 1:<3} | {event:<45} | {time_display:<45} | {loc:<27} | {remind}")