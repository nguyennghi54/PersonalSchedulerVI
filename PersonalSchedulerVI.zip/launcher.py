﻿import subprocess
import sys
import importlib.util
import os

REQUIRED_PACKAGES = [
    "ttkbootstrap",
    "underthesea",
    "scipy",
    "joblib",
    "scikit-learn",

]


def install(package):
    print(f"--- Đang cài đặt thư viện thiếu: {package} ---")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"Đã cài xong: {package}")
    except subprocess.CalledProcessError:
        print(f"Không thể cài đặt: {package}. Vui lòng kiểm tra kết nối mạng.")


def check_environment():
    # Kiểm tra môi trường & cài đặt thư viện thiếu
    print("⏳ Đang kiểm tra môi trường...")
    for package in REQUIRED_PACKAGES:
        spec = importlib.util.find_spec(package)
        if spec is None:
            install(package)
        else:
            pass
def main():
    check_environment()
    print("\nĐang khởi động ứng dụng...\n")
    # Import App chính
    try:
        import app
        main_app = app.SchedulerApp()
        main_app.mainloop()

    except ImportError as e:
        print("Không thể import file 'app.py'.")
        print(f"Error: {e}")
        print("Đảm bảo các file nằm cùng thư mục.")
        input("Nhấn Enter để thoát...")

if __name__ == "__main__":
    main()