﻿# @title DATABASE & UI
from nlp import *
import sqlite3
import threading
import time
import json
import calendar
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import messagebox, filedialog
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.widgets import DateEntry

from nlp import *

# ==========================================
# DATABASE MANAGER
# ==========================================
class Database:
    def __init__(self, db_name="scheduler.db"):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.create_table()


    # Khởi tạo bảng
    def create_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT,
                start_time TEXT,
                end_time TEXT,
                location TEXT,
                reminder_minutes INTEGER,
                is_notified INTEGER DEFAULT 0
            )
        """)
        self.conn.commit()

    # Thêm event
    def add_event(self, name, start, end, loc, remind):
        self.cursor.execute("""
            INSERT INTO events (event, start_time, end_time, location, reminder_minutes)
            VALUES (?, ?, ?, ?, ?)
        """, (name, start, end, loc, remind))
        self.conn.commit()

    # Xếp theo ID
    def get_all_events(self):
        self.cursor.execute("SELECT * FROM events ORDER BY id ASC")
        return self.cursor.fetchall()

    # Đánh dấu event đã thông báo
    def mark_notified(self, event_id):
        self.cursor.execute("UPDATE events SET is_notified = 1 WHERE id = ?", (event_id,))
        self.conn.commit()

    # Xóa event
    def delete_event(self, event_id):
        self.cursor.execute("DELETE FROM events WHERE id = ?", (event_id,))
        self.conn.commit()

    # Sửa event
    def update_event(self, record_id, name, start, end, loc, remind):
        self.cursor.execute("""
            UPDATE events
            SET event=?, start_time=?, end_time=?, location=?, reminder_minutes=?, is_notified=0
            WHERE id=?
        """, (name, start, end, loc, remind, record_id))
        self.conn.commit()

    # Kiểm tra trùng lặp tgian bắt đầu event
    def check_overlap(self, new_start_str, exclude_id=None):
        if not new_start_str: return False, None
        query = "SELECT id, event, start_time FROM events WHERE id != ?"
        params = [exclude_id if exclude_id else -1]
        self.cursor.execute(query, params)
        rows = self.cursor.fetchall()
        for row in rows:
            _, e_name, e_start = row
            if new_start_str == e_start:
                return True, e_name
        return False, None

    # Kiểm tra cú pháp datetime chuẩn
    def check_valid_datetime(date_text):
        try:
            if not date_text: return False
            datetime.strptime(date_text, "%Y-%m-%d %H:%M:%S")
            return True
        except ValueError:
            return False

# ==========================================
# UI LOGIC
# ==========================================
import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.widgets import DateEntry

class SchedulerApp(ttk.Window):
    def __init__(self):
        super().__init__(themename="darkly")
        self.title("AI Smart Scheduler (Desktop v3.0)")
        self.geometry("1300x750")
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 11), rowheight=30)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

        self.db = Database()
        self.scheduler_logic = SchedulerMain()
        self.setup_ui()
        self.load_data()

        # Luồng chạy ngầm
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.background_checker, daemon=True)
        self.thread.start()
        # Xử lý tắt app an toàn
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def setup_ui(self):
        # --TOP (Input area)--
        input_frame = ttk.Labelframe(self, text="Nhập câu tiếng Việt", padding=15)
        input_frame.pack(fill=X, padx=10, pady=5)

        self.entry_var = tk.StringVar()
        self.entry_task = ttk.Entry(input_frame, textvariable=self.entry_var, font=("Segoe UI", 11))
        self.entry_task.pack(side=LEFT, padx=5, fill=X, expand=True)
        self.entry_task.insert(0, "Nhắc t họp nhóm lúc 10 giờ sáng mai ở phòng 302, nhắc trc 15 phút") #textholder

        ttk.Button(input_frame, text="Phân tích & Thêm", command=self.process_input, bootstyle=SUCCESS).pack(
            side=LEFT, padx=5)

        tool_frame = ttk.Frame(self, padding=5)
        tool_frame.pack(fill=X, padx=10)
        # Các nút tiện ích
        ttk.Button(tool_frame, text="Xem Lịch", command=self.open_calendar_view, bootstyle=INFO).pack(side=LEFT)
        ttk.Button(tool_frame, text="Xuất JSON", command=self.export_json, bootstyle=OUTLINE).pack(side=LEFT, padx=5)

        # --MIDDLE (Danh sách)--
        list_frame = ttk.Frame(self)
        list_frame.pack(fill=BOTH, expand=True, padx=10, pady=5)
        cols = ("ID", "Sự Kiện", "Bắt Đầu", "Kết Thúc", "Địa Điểm", "Nhắc Trước")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", bootstyle="info", height=15)
        scrollbar = ttk.Scrollbar(list_frame, orient=VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        # Thiết lập các cột DS
        self.tree.heading("ID", text="ID");
        self.tree.column("ID", width=40, anchor=CENTER)
        self.tree.heading("Sự Kiện", text="Nội Dung");
        self.tree.column("Sự Kiện", anchor=W)
        self.tree.heading("Bắt Đầu", text="Bắt Đầu");
        self.tree.column("Bắt Đầu", width=140, anchor=CENTER)
        self.tree.heading("Kết Thúc", text="Kết Thúc");
        self.tree.column("Kết Thúc", width=140, anchor=CENTER)
        self.tree.heading("Địa Điểm", text="Địa Điểm");
        self.tree.column("Địa Điểm", width=150, anchor=W)
        self.tree.heading("Nhắc Trước", text="Nhắc(p)");
        self.tree.column("Nhắc Trước", width=80, anchor=CENTER)

        # --BOTTOM (Các nút chức năng)--
        btn_frame = ttk.Frame(self, padding=10)
        btn_frame.pack(fill=X)
        ttk.Button(btn_frame, text="Xóa", command=self.delete_selected, bootstyle=DANGER).pack(side=RIGHT)
        ttk.Button(btn_frame, text="Sửa", command=self.edit_selected, bootstyle=WARNING).pack(side=RIGHT, padx=5)
        ttk.Button(btn_frame, text="Làm mới", command=self.load_data, bootstyle=SECONDARY).pack(side=RIGHT, padx=5)

    # ==========================================
    # LOGIC XỬ LÝ
    # ==========================================
    # Xử lý và thêm event sau khi nhấn nút Thêm
    def process_input(self):
        raw_text = self.entry_task.get()
        if not raw_text: return
        result = self.scheduler_logic.process(raw_text) # Chuỗi input sau khi qua module NLP
        # Fix thêm giây, mặc định end time (+1 tiếng)
        try:
            dt = datetime.strptime(result['start_time'], "%Y-%m-%d %H:%M")
            result['start_time'] = dt.strftime("%Y-%m-%d %H:%M:%00")
        except ValueError:
            pass
        if not result['end_time'] and result['start_time']:
            try:
                s_dt = datetime.strptime(result['start_time'], "%Y-%m-%d %H:%M:%S")
                result['end_time'] = (s_dt + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            except:
                pass

        # Check trùng start time lịch
        is_ov, conflict = self.db.check_overlap(result['start_time'])
        if is_ov:
            if not messagebox.askyesno("Cảnh báo", f"Trùng lịch với '{conflict}'. Vẫn thêm?"): return

        self.db.add_event(
            result['event'], result['start_time'], result['end_time'],
            result['location'], result['reminder_minutes']
        )
        self.entry_task.delete(0, END)
        self.load_data()

    # Lấy lịch trong database load lên bảng
    def load_data(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        rows = self.db.get_all_events()
        for row in rows:
            self.tree.insert("", END, values=row[:6])

    def delete_selected(self):
        selected = self.tree.selection()
        if selected:
            if messagebox.askyesno("Xác nhận", "Xóa sự kiện này?"):
                item = self.tree.item(selected[0])
                self.db.delete_event(item['values'][0])
                self.load_data()

    def edit_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Chú ý", "Chọn dòng để sửa!")
            return
        values = self.tree.item(selected[0])['values']
        rec_id = values[0]
        # Helper để chắc chắn đúng format
        def split_dt(dt_str):
            try:
                dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
                return dt.strftime("%Y-%m-%d"), dt.strftime("%H:%M")
            except:
                try:
                    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M"); return dt.strftime("%Y-%m-%d"), dt.strftime(
                        "%H:%M")
                except:
                    return datetime.now().strftime("%Y-%m-%d"), "00:00"
        s_date, s_time = split_dt(values[2])
        e_date, e_time = split_dt(values[3])

        # --POPUP EDIT FORM--
        win = ttk.Toplevel(self)
        win.title("Sửa Sự Kiện")
        win.geometry("500x700")
        content = ttk.Frame(win, padding=20)
        content.pack(fill=BOTH, expand=True)
        # Thêm biến lưu trữ DateEntry
        self.temp_de_start = None
        self.temp_de_end = None
        content = ttk.Frame(win, padding=20)
        content.pack(fill=BOTH, expand=True)

        # 1. Tên
        ttk.Label(content, text="Tên sự kiện:", font=("Segoe UI", 10, "bold")).pack(anchor=W)
        ent_name = ttk.Entry(content, width=50)
        ent_name.pack(fill=X, pady=(5, 15))
        ent_name.insert(0, values[1])
        # 2. Start Time
        ttk.Label(content, text="Bắt đầu:", font=("Segoe UI", 10, "bold"), bootstyle="primary").pack(anchor=W)
        f_start = ttk.Frame(content);
        f_start.pack(fill=X, pady=(5, 15))
        # 3. Start time
        self.temp_de_start = DateEntry(f_start, dateformat='%Y-%m-%d', startdate=datetime.strptime(s_date, "%Y-%m-%d"),
                                       width=15, bootstyle="primary")
        self.temp_de_start.pack(side=LEFT, padx=(0, 10))
        te_start = ttk.Entry(f_start, width=10);
        te_start.insert(0, s_time);
        te_start.pack(side=LEFT)
        ttk.Label(f_start, text="(Giờ:Phút)").pack(side=LEFT, padx=5)
        # 4. End time
        ttk.Label(content, text="Kết thúc:", font=("Segoe UI", 10, "bold"), bootstyle="primary").pack(anchor=W)
        f_end = ttk.Frame(content);
        f_end.pack(fill=X, pady=(5, 15))
        self.temp_de_end = DateEntry(f_end, dateformat='%Y-%m-%d', startdate=datetime.strptime(e_date, "%Y-%m-%d"),
                                     width=15, bootstyle="primary")
        self.temp_de_end.pack(side=LEFT, padx=(0, 10))
        te_end = ttk.Entry(f_end, width=10);
        te_end.insert(0, e_time);
        te_end.pack(side=LEFT)
        # 5. Location & Reminder
        ttk.Label(content, text="Địa điểm:", font=("Segoe UI", 10, "bold")).pack(anchor=W)
        ent_loc = ttk.Entry(content);
        ent_loc.pack(fill=X, pady=(5, 15))
        ent_loc.insert(0, values[4] if values[4] else "")
        ttk.Label(content, text="Nhắc trước (phút):", font=("Segoe UI", 10, "bold")).pack(anchor=W)
        # Nếu remind null
        remind_val = str(values[5]).replace(" phút", "").replace("-", "0")
        if remind_val == 'None': remind_val = "0"
        ent_remind = ttk.Entry(content);
        ent_remind.pack(fill=X, pady=(5, 20))
        ent_remind.insert(0, remind_val)

        # --Lưu thay đổi vào database--
        def save():
            try:
                # Lấy ngày từ DateEntry + giờ từ Entry
                d_start = self.temp_de_start.entry.get()
                d_end = self.temp_de_end.entry.get()
                t_start = te_start.get().strip()
                t_end = te_end.get().strip()
                # tự thêm :00 nếu null
                if len(t_start.split(':')) == 2: t_start += ":00"
                if len(t_end.split(':')) == 2: t_end += ":00"
                new_start = f"{d_start} {t_start}"
                new_end = f"{d_end} {t_end}"
                name = ent_name.get()
                loc = ent_loc.get()
                remind = ent_remind.get()
                print(f"DEBUG: Trying to save: {new_start} -> {new_end}")
                # Kiểm tra logic hợp lệ (end > start)
                try:
                    datetime.strptime(new_start, "%Y-%m-%d %H:%M:%S")
                    datetime.strptime(new_end, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    messagebox.showerror("Lỗi format",
                                         f"Ngày giờ không hợp lệ!\nFormat: YYYY-MM-DD HH:MM\nBạn nhập: {new_start}")
                    return
                if new_start > new_end:
                    messagebox.showerror("Lỗi logic", "Ngày kết thúc phải sau ngày bắt đầu!")
                    return
                # Check trùng start time
                is_ov, conf = self.db.check_overlap(new_start, exclude_id=rec_id)
                if is_ov:
                    if not messagebox.askyesno("Cảnh báo trùng",
                                               f"Thời gian này trùng với sự kiện:\n'{conf}'\nVẫn muốn lưu?"): return
                # Lưu vào DB
                self.db.update_event(rec_id, name, new_start, new_end, loc, remind)
                # Refresh UI
                self.load_data()
                win.destroy()
                messagebox.showinfo("Thành công", "Đã lưu thay đổi!")

            except Exception as e:
                import traceback
                err_msg = traceback.format_exc()
                print(err_msg)
                messagebox.showerror("Lỗi system", f"Không thể lưu!\nChi tiết lỗi:\n{e}")

        ttk.Button(content, text="Lưu Thay Đổi", command=save, bootstyle="success").pack(fill=X, pady=20)

    # --Xuất Json--
    def export_json(self):
        events = self.db.get_all_events()
        data = []
        for ev in events:
            data.append({
                "id": ev[0], "event": ev[1], "start": ev[2],
                "end": ev[3], "location": ev[4], "remind": ev[5]
            })

        file_path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            title="Lưu file backup"
        )

        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                messagebox.showinfo("Thành công", f"Đã xuất file tại:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    # --CALENDAR VIEW--
    def open_calendar_view(self):
        cal_win = ttk.Toplevel(self)
        cal_win.title("Lịch Sự Kiện")
        cal_win.geometry("600x600")
        # Biến để điều hướng tháng năm
        current_date = datetime.now()
        self.cal_month = current_date.month
        self.cal_year = current_date.year

        header = ttk.Frame(cal_win, padding=10)
        header.pack(fill=X)
        lbl_header = ttk.Label(header, text="", font=("Segoe UI", 14, "bold"))
        lbl_header.pack(side=LEFT, expand=True)

        def update_calendar():
            # Xóa lịch cũ
            for widget in body.winfo_children(): widget.destroy()
            lbl_header.config(text=f"Tháng {self.cal_month} / {self.cal_year}")

            # Lấy data tháng đó
            events = self.db.get_all_events()
            month_events = {}  # Map: day -> ds event
            for ev in events:
                try:
                    dt = datetime.strptime(ev[2], "%Y-%m-%d %H:%M:%S")
                    if dt.year == self.cal_year and dt.month == self.cal_month:
                        if dt.day not in month_events: month_events[dt.day] = []
                        month_events[dt.day].append(ev[1])  # Lưu tên sự kiện
                except:
                    pass

            # Vẽ lưới lịch
            cal_matrix = calendar.monthcalendar(self.cal_year, self.cal_month)
            days_name = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
            for i, d in enumerate(days_name):
                ttk.Label(body, text=d, bootstyle="secondary", anchor=CENTER).grid(row=0, column=i, sticky="nsew",
                                                                                   padx=2, pady=2)
            # Vẽ các ngày
            for r, week in enumerate(cal_matrix):
                for c, day in enumerate(week):
                    if day == 0:
                        ttk.Label(body, text="").grid(row=r + 1, column=c)
                    else:
                        # Logic style
                        style_btn = "outline"
                        if day in month_events: style_btn = "danger"  # Có sự kiện -> Màu đỏ
                        if day == datetime.now().day and self.cal_month == datetime.now().month:
                            style_btn = "success"  # Hôm nay -> Màu xanh

                        btn = ttk.Button(body, text=str(day), bootstyle=style_btn,
                                         command=lambda d=day, evs=month_events.get(day, []): show_day_detail(d, evs))
                        btn.grid(row=r + 1, column=c, sticky="nsew", padx=2, pady=2, ipady=10)
            for i in range(7): body.columnconfigure(i, weight=1)

        # Show sự kiện có trong ngày
        def show_day_detail(day, evs):
            msg = f"Sự kiện ngày {day}/{self.cal_month}:\n\n"
            if not evs:
                msg += "Không có sự kiện nào."
            else:
                for e in evs: msg += f"• {e}\n"
            messagebox.showinfo("Chi tiết", msg)
        def prev_month():
            self.cal_month -= 1
            if self.cal_month == 0:
                self.cal_month = 12;
                self.cal_year -= 1
            update_calendar()
        def next_month():
            self.cal_month += 1
            if self.cal_month == 13:
                self.cal_month = 1;
                self.cal_year += 1
            update_calendar()

        ttk.Button(header, text="<", command=prev_month).pack(side=LEFT)
        ttk.Button(header, text=">", command=next_month).pack(side=RIGHT)
        body = ttk.Frame(cal_win, padding=10)
        body.pack(fill=BOTH, expand=True)

        update_calendar()

    # ==========================================
    # BACKGROUND THREAD
    # ==========================================
    def background_checker(self):
        while not self.stop_event.is_set():
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
            try:
                events = self.db.get_all_events()
                for ev in events:
                    eid, name, start, end, loc, remind, notified = ev
                    if notified == 1: continue

                    try:
                        s_dt = datetime.strptime(start, "%Y-%m-%d %H:%M:%S")
                    except:
                        try:
                            s_dt = datetime.strptime(start, "%Y-%m-%d %H:%M")
                        except:
                            continue

                    s_dt = s_dt.replace(second=0)
                    remind_val = remind if remind else 0
                    remind_dt = s_dt - timedelta(minutes=remind_val)

                    if now_str == remind_dt.strftime("%Y-%m-%d %H:%M"):
                        self.db.mark_notified(eid)
                        self.after(0, lambda n=name, l=loc: messagebox.showinfo("NHẮC NHỞ", f"🔔 {n}\n📍 {l}"))
                        self.after(1000, self.load_data)
            except:
                pass
            self.stop_event.wait(20)
    def on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.destroy()
            self.quit()
if __name__ == "__main__":
    app = SchedulerApp()
    app = SchedulerApp()
    app.mainloop()